# -*- coding: utf-8 -*-
import os
import requests
from PyPDF2 import PdfReader
from langchain import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain.embeddings.openai import OpenAIEmbeddings  # You may want to change this if using Gemini embeddings
from langchain.text_splitter import CharacterTextSplitter
import streamlit as st

st.title('Smart Support Assistant')

# Google Gemini API Key input
gemini_api_key = st.sidebar.text_input('Google Gemini API Key')

# Setting the environment variable for Gemini API key
os.environ['GEMINI_API_KEY'] = "AIzaSyDbStyiiw5KCWJ5_YK4q6b6-MCz1jNdo2Q";

# Function to call Google Gemini LLM
def call_gemini_llm(prompt):
    url = "https://gemini.googleapis.com/v1/models/YOUR_MODEL_NAME:generateText"  # Replace with actual endpoint
    headers = {
        "Authorization": f"Bearer {gemini_api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "prompt": prompt,
        "maxTokens": 150,  # Customize as needed
        "temperature": 0.7  # Customize as needed
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 200:
        return response.json().get("generatedText", "")  # Adjust according to actual response structure
    else:
        st.error(f"Error: {response.status_code} - {response.text}")
        return ""

def generate_response(input_text):
   // embeddings = OpenAIEmbeddings(openai_api_key=gemini_api_key)  # You may need to change this to use Gemini embeddings
    pdf_text = pdf_reader()
   // document_search = FAISS.from_texts(pdf_text, embeddings)

    # Loading the QA chain for Gemini
    chain = load_qa_chain(call_gemini_llm, chain_type="refine")  # Use the call_gemini_llm function

   // docs = document_search.similarity_search(input_text)
    result = chain.run(input_documents=docs, question=input_text)

    if input_text:
        st.info(result)

def pdf_reader():
    pdfreader = PdfReader("sg_log.pdf")

    # Read text from PDF
    raw_text = ''

    for i, page in enumerate(pdfreader.pages):
        content = page.extract_text()
        if content:
            raw_text += content

    # Split text using CharacterTextSplitter to avoid increasing token size
    text_splitter = CharacterTextSplitter(
        separator="\n",
        chunk_size=800,
        chunk_overlap=200,
        length_function=len
    )

    texts = text_splitter.split_text(raw_text)
    return texts

with st.form('my_form'):
    text = st.text_area('Enter text:', 'What are the three key pieces of advice for learning how to code?')
    submitted = st.form_submit_button('Submit')
    if submitted:
        generate_response(text)
