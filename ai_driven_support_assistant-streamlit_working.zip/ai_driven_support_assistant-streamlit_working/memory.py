from langchain import OpenAI
from langchain.chains import LLMChain, ConversationChain
from langchain.chains.conversation.memory import (ConversationBufferMemory,
                                                  ConversationSummaryMemory,
                                                  ConversationBufferWindowMemory,
                                                  ConversationKGMemory)
from langchain.callbacks import get_openai_callback


llm = OpenAI(
    temperature=0,
    openai_api_key="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",
    model_name='text-davinci-003'  # can be used with llms like 'gpt-3.5-turbo'
)

def count_tokens(chain, query):
    with get_openai_callback() as cb:
        result = chain.run(query)
        print(f'Spent a total of {cb.total_tokens} tokens')

    return result

conversation = ConversationChain(
    llm=llm,
)

conversation_sum = ConversationChain(
    llm=llm,
    memory=ConversationSummaryMemory(llm=llm)
)

conversation_kg = ConversationChain(
    llm=llm,
    memory=ConversationKGMemory(llm=llm)
)

# without count_tokens we'd call `conversation_sum("Good morning AI!")`
# but let's keep track of our tokens:
# count_tokens(
#     conversation_sum,
#     "Good morning AI!"
# )

count_tokens(
    conversation_sum,
    "My interest here is to explore the potential of integrating Large Language Models with external knowledge"
)

# count_tokens(
#     conversation_sum,
#     "Which data source types could be used to give context to the model?"
# )

count_tokens(
    conversation_sum,
    "What is my aim again?"
)

print(conversation_sum.memory.buffer)